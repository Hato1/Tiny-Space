"""Constants"""

SCALE = 2
RESOLUTION = (640 * SCALE, 400 * SCALE)
