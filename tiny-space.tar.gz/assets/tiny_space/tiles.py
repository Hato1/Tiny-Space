"""
Holds the classes for the structures that are placed on the map
"""

# from typing import Type

# from .thing import Nothing, Thing


# class Tile:
#     def __init__(self, contains: Type[Thing] | Type[Nothing] = Nothing):
#         self.contains = contains
